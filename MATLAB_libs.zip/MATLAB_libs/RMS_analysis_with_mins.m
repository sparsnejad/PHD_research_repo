function [ output_args, min ] = RMS_analysis_with_mins( input_matrix )
%CONFUSION_MATRIX_ANALYSIS Summary of this function goes here
%   Detailed explanation goes here
[input_size, temp] = size(input_matrix);
target=0;
mini= 1;
counter = 1;
temp = zeros(input_size,1);
for row = 1:input_size
    for col= 1:input_size
        if(row == col)
            target= 1 - input_matrix(row, col);
% 			if (mini > 1 - input_matrix(row, col))
% 				mini= 1 - input_matrix(row, col);
% 			end
        else
            target= input_matrix(row, col);
			if (mini >input_matrix(row, col))
				mini = input_matrix(row, col);
			end
        end
        if(row <= col)
            temp(counter, 1) = target;
            counter = counter+1;
        end
    end
end
output_args= rms(1-temp);
min= mini;
clearvars target input_size row col temp mini counter temp;


end

