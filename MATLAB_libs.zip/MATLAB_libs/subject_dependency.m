
sorted_data_analysis
std_matrix = zeros(66,6);

std_matrix(:,1)= std(all_data(:,3 :5 )')';
std_matrix(:,2)= std(all_data(:,6 :8 )')';
std_matrix(:,3)= std(all_data(:,9 :11)')';
std_matrix(:,4)= std(all_data(:,12:14)')';
std_matrix(:,5)= std(all_data(:,15:17)')';
std_matrix(:,6)= std(all_data(:,3 :17)')';

all_data_int_person= [mean(all_data(:,3 :5 ),2) mean(all_data(:,6 :8 ),2) mean(all_data(:,9 :11),2) mean(all_data(:,12:14),2) mean(all_data(:,15:17),2)];
int_p_std= std(all_data_int_person')';

%y= mean(std_matrix, 2)


%std_matrix= [all_data(:,1:2) std_matrix];
subject_dependency_overall_c4 = (1+int_p_std)./(1+mean(std_matrix(:,1:5) ,2));
RMS_subject_dependency_overall_c4= rms(subject_dependency_overall_c4);

for n=1:5
    subject_dependency_matrix_c4(:,n) = (1+std(all_data_int_person(1:1:n))')' ./(1+mean(std_matrix(:,1:n) ,2));
end
RMS_subject_dependency_matrix_c4= rms(subject_dependency_matrix_c4)


% subject_dependency_matrix= zeros(66,5);
% for n=1:66
%     if (std_matrix(n,8)== 0)
%         subject_dependency_matrix(n,1:5)=0;
%     else
%         subject_dependency_matrix(n,1:5)= std_matrix(n, 3:7)/ std_matrix(n,8);
%     end
% end
% 
% subject_dependency_matrix= [all_data(:,1:2) subject_dependency_matrix];
        


