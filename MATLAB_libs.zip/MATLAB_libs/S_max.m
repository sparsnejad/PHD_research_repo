function [out1] = S_max(input_matrix)
%S_MAX Summary of this function goes here
%   Detailed explanation goes here
[input_size, temp] = size(input_matrix);

maxi= 0;
for row = 1:input_size
    for col= 1:input_size
        if(row == col)
            %do noting
        else
			if (input_matrix(row, col) > maxi)
				maxi = input_matrix(row, col);
			end
        end
    end
end
out1 = maxi;
clearvars maxi input_size row col temp;
end

