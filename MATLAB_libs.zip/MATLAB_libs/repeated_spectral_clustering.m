% similar to k-fold cross validation
clc
k=5;
ultimate_best_table_label = [];
ultimate_best_table = [];
ultimate_best_min = 0;
ultimate_best_confusion_matrix = 0;

dist = table;
dist_original_table = original_table;
%dist(dist<0.4) = 0;
dist_original_table(dist_original_table<0.4) = 0;
%sim_value= 0.9393;
%sim_value= 0.9113;
%sim_value= 0.9587;
sim_value= 0.8721;
S = exp(-dist.^2);
issymmetric(S);
S_eps = S;
S_eps(S_eps<sim_value) = 0;
%Create a graph object from S.
G_eps = graph(S_eps);
%Visualize the similarity graph.
figure(1)
plot(G_eps)
cluster_list= unique(conncomp(G_eps));
kx = max(cluster_list);

for n=1:100
    Matlabs_Spectral_Clustering_enhanced
    if (best_min >= ultimate_best_min)
        if(best_confusion_matrix > ultimate_best_confusion_matrix)
            ultimate_best_table_label = best_table_label ;
            ultimate_best_table = best_table;
            ultimate_best_min = best_min;
            ultimate_best_confusion_matrix = best_confusion_matrix;
            ultimate_cluster= C;
            ultimate_idx3= idx3;
            ultimate_S_eps = S_eps;
        end
    end
    
    
end

ultimate_best_min
ultimate_best_confusion_matrix

%figure(1)
%G_eps = graph(ultimate_S_eps);
%plot(G_eps)

[elements, ~] = size(ultimate_cluster);

Clusters_based_on_BF_and_TF= cell(elements,1);
BF_and_TF_clusters_unified= [];

for n = 1:elements
    
    Clusters_based_on_BF_and_TF{n} = waveform_LUT(ultimate_cluster{n}.', 1:2);
    [Cell_size, ~] = size(Clusters_based_on_BF_and_TF{n});
    A=ones(Cell_size,1)*n;
    Clusters_based_on_BF_and_TF{n} = [Clusters_based_on_BF_and_TF{n} A];
    
    BF_and_TF_clusters_unified = [BF_and_TF_clusters_unified ; Clusters_based_on_BF_and_TF{n}];

end

%hold on
%gscatter(X{n}(:,1),X{n}(:,2),X{n}(:,3));
figure(2)
gscatter(BF_and_TF_clusters_unified(:,1),BF_and_TF_clusters_unified(:,2),BF_and_TF_clusters_unified(:,3));